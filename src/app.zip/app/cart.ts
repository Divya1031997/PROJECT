export class Cart {

 
 itemId:number;
 quantity:number;
 price:number;




}